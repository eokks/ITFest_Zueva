package com.example.olimpiadazueva;

//Просто нужный интерфейс, но я перенесла его сюда
interface OnlClickShowModalInterface {
    void showModal(OlimGame game);
}
